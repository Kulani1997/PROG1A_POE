/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog1a_poe;

/**
 *
 * @author sizib
 */
public class PROG1A_POE {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
